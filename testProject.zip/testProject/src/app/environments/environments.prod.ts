
export const environment = {
    production: true,
    http:'http://',
    https:'https://',
     api_url: "artelir.com:3018/",
     image_url:"artelir.com",
    // version: require('../../package.json').version
    version: '0.0.0'
  };
  