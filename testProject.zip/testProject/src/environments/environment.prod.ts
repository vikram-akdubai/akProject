export const environment = {
  production: true,
  http:'https://',
  https:'https://',
  api_url: "artelir.com:3018/",
  image_url:"artelir.com",

  version: "0.0.0"
};