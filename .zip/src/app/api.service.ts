import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpParams} from '@angular/common/http';
import 'rxjs/add/operator/map';
import { map } from "rxjs/operators";
import { Observable } from 'rxjs';
const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded','Access-Control-Expose-Headers':'Access-Control-*', 'Access-Control-Allow-Headers':'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept', 'Access-Control-Allow-Methods':'GET, POST, PUT, DELETE, OPTIONS, HEAD','Access-Control-Allow-Origin':'*', 'Allow': 'GET, POST, PUT, DELETE, OPTIONS, HEAD'}) };


@Injectable({
  
//   ->header("Access-Control-Expose-Headers", "Access-Control-*")
// ->header("Access-Control-Allow-Headers", "Access-Control-*, Origin, X-Requested-With, Content-Type, Accept")
// ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, HEAD')
// ->header('Access-Control-Allow-Origin', '*')
// ->header('Allow', 'GET, POST, PUT, DELETE, OPTIONS, HEAD');
  providedIn: 'root'
})
export class ApiService {

  public getNews(){
    return this.httpClient.get(`http://3.14.152.153:3018/website/getComments`);
  }


  public livecorona(){
    return this.httpClient.get(`https://coronavirus-19-api.herokuapp.com/all`);
  }

  public livecoronadata(){
    return this.httpClient.get(`https://coronavirus-19-api.herokuapp.com/countries`);
  }

  public PostNews(name:any,email:any,comment:any): Observable<any> 
      {
        console.log(httpOptions);  
        let params = new HttpParams(); 
        params = params.append('name', name);
        params = params.append('email', email);
        params = params.append('comment', comment);

        return this.httpClient.post(`http://3.14.152.153:3018/website/postComments`, params, httpOptions).map((res: HttpResponse<JSON>) => res);
       }

       constructor(private httpClient: HttpClient) {

        }

        getsuspectedCase() {
          return this.httpClient.get("https://apigw.nubentos.com:443/t/nubentos.com/ncovapi/1.0.0/cases/suspected", {
            headers: new HttpHeaders().set(
              "Authorization",
              "Bearer 8bbc49b2-2f84-34dc-b201-cc673dd26f3a"
            )
          });
        }
}
