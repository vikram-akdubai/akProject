import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DoctorregRoutingModule } from './doctorreg-routing.module';
import { DoctorregComponent } from './doctorreg.component';


@NgModule({
  declarations: [DoctorregComponent],
  imports: [
    CommonModule,
    DoctorregRoutingModule
  ]
})
export class DoctorregModule { }
