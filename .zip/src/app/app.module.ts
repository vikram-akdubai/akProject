import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HomecontainerComponent } from './homecontainer/homecontainer.component';
import { ArtsliderComponent } from './artslider/artslider.component';
import { CountToModule } from 'angular-count-to';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HomecontainerComponent,
    ArtsliderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    CountToModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
