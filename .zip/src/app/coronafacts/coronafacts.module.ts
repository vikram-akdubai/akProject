import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoronafactsRoutingModule } from './coronafacts-routing.module';
import { CoronafactsComponent } from './coronafacts.component';


@NgModule({
  declarations: [CoronafactsComponent],
  imports: [
    CommonModule,
    CoronafactsRoutingModule
  ]
})
export class CoronafactsModule { }
