import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coronafacts',
  templateUrl: './coronafacts.component.html',
  styleUrls: ['./coronafacts.component.css']
})
export class CoronafactsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
