import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BlogthreeRoutingModule } from './blogthree-routing.module';
import { BlogthreeComponent } from './blogthree.component';


@NgModule({
  declarations: [BlogthreeComponent],
  imports: [
    CommonModule,
    BlogthreeRoutingModule
  ]
})
export class BlogthreeModule { }
