import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogthree',
  templateUrl: './blogthree.component.html',
  styleUrls: ['./blogthree.component.css']
})
export class BlogthreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
