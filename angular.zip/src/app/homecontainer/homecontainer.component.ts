import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecontainer',
  templateUrl: './homecontainer.component.html',
  styleUrls: ['./homecontainer.component.css']
})
export class HomecontainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
